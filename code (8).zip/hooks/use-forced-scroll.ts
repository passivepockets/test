"use client"

import { useEffect, useRef, useState } from "react"

export function useForcedScroll() {
  const [scrollProgress, setScrollProgress] = useState(0)
  const [internalScroll, setInternalScroll] = useState(0)
  const containerRef = useRef<HTMLDivElement>(null)
  const [isClient, setIsClient] = useState(false)
  const [animationComplete, setAnimationComplete] = useState(false)
  const [hasCompletedOnce, setHasCompletedOnce] = useState(false)

  useEffect(() => {
    setIsClient(true)
  }, [])

  useEffect(() => {
    if (scrollProgress >= 1 && !hasCompletedOnce) {
      setAnimationComplete(true)
      setHasCompletedOnce(true)
    }
  }, [scrollProgress, hasCompletedOnce])

  useEffect(() => {
    if (!isClient) return

    const handleWheel = (e: WheelEvent) => {
      if (!containerRef.current) return

      const rect = containerRef.current.getBoundingClientRect()
      const viewportHeight = window.innerHeight
      const componentHeight = rect.height

      const componentCenter = rect.top + componentHeight / 2
      const viewportCenter = viewportHeight / 2
      const distanceFromCenter = Math.abs(componentCenter - viewportCenter)
      const maxDistance = viewportHeight * 0.2

      const isCentered = distanceFromCenter < maxDistance
      const currentProgress = internalScroll / 100

      const shouldLock = isCentered && !hasCompletedOnce

      if (shouldLock) {
        // Prevent scrolling past animation bounds
        if ((e.deltaY > 0 && currentProgress >= 1) || (e.deltaY < 0 && currentProgress <= 0)) {
          e.preventDefault()
          return
        }

        e.preventDefault()

        setInternalScroll((prev) => {
          const newScroll = prev + e.deltaY * 0.15
          return Math.max(0, Math.min(100, newScroll))
        })
      }
    }

    window.addEventListener("wheel", handleWheel, { passive: false })
    return () => {
      window.removeEventListener("wheel", handleWheel)
    }
  }, [isClient, internalScroll, hasCompletedOnce])

  useEffect(() => {
    setScrollProgress(internalScroll / 100)
  }, [internalScroll])

  return { scrollProgress, containerRef }
}
