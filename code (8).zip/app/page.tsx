"use client"

import { useRouter } from "next/navigation"
import { useState, useEffect, useRef } from "react"
import Image from "next/image"
import { Copy, Check } from "lucide-react"
import { ScrollText } from "@/components/scroll-text"
import { GamesShowcase } from "@/components/games-showcase"
import { FeaturesSection } from "@/components/features-section"
import { TestimonialsSection, FAQSection } from "@/components/testimonials-faq"
import { RotatingGameTitle } from "@/components/rotating-game-title"
import { useScrollReveal } from "@/hooks/use-scroll-reveal"
import BeamsBackground from "@/components/beams-background"
import { MiniShop } from "@/components/mini-shop"

export default function Home() {
  const router = useRouter()
  const [copied, setCopied] = useState(false)
  const heroRef = useRef<HTMLDivElement>(null)
  const { ref: executorsRef, isVisible: executorsVisible } = useScrollReveal()
  const { ref: gamesRef, isVisible: gamesVisible } = useScrollReveal()
  const { ref: featuresRef, isVisible: featuresVisible } = useScrollReveal()
  const { ref: statsRef, isVisible: statsVisible } = useScrollReveal()
  const { ref: testimonialsRef, isVisible: testimonialsVisible } = useScrollReveal()
  const { ref: faqRef, isVisible: faqVisible } = useScrollReveal()

  useEffect(() => {
    const handleScroll = () => {
      // Handle scroll effects if needed
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const copyToClipboard = () => {
    navigator.clipboard.writeText('loadstring(game:HttpGet("https://getgold.cc/load"))()')
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleGetKey = () => {
    router.push("/keys")
  }

  return (
    <div className="min-h-screen text-white relative animate-page-slide-down">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-[#0a0a0a]/80 backdrop-blur-sm z-50 border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <Image src="/gold-icon.png" alt="gold" width={32} height={32} className="w-8 h-8" />
            <span className="text-xl font-bold tracking-tight" style={{ fontFamily: "var(--font-display)" }}>
              gold
            </span>
          </div>
          <div className="flex gap-8">
            <a href="#" className="hover:text-gray-300 transition">
              Shop
            </a>
            <a href="#" className="hover:text-gray-300 transition">
              Sign In
            </a>
          </div>
        </div>
      </nav>

      <BeamsBackground intensity="strong" className="bg-[#0a0a0a]">
        <section ref={heroRef} className="pt-32 pb-20 px-4 relative overflow-hidden animate-stagger-in stagger-1">
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute top-20 left-1/4 w-[600px] h-[600px] bg-[#FFB800]/20 rounded-full blur-3xl" />
            <div className="absolute bottom-20 right-1/4 w-[600px] h-[600px] bg-[#FFA500]/15 rounded-full blur-3xl" />
            <div className="absolute top-1/2 right-1/3 w-[500px] h-[500px] bg-[#FFBF00]/10 rounded-full blur-3xl" />
          </div>

          <div className="max-w-4xl mx-auto text-center relative z-10">
            <h1
              className="text-7xl sm:text-8xl font-bold mb-6 text-[#FFB800] drop-shadow-lg"
              style={{ fontFamily: "var(--font-display)", letterSpacing: "-0.05em" }}
            >
              gold
            </h1>
            <p className="text-xl sm:text-2xl text-gray-300 mb-8 leading-relaxed">
              The best <RotatingGameTitle /> script
            </p>

            <div className="flex justify-center mb-12">
              <div className="inline-flex items-center gap-2 px-4 py-3 bg-[#1a1a1a] border border-white/10 rounded-xl max-w-md">
                <code className="text-sm font-mono text-white/90 truncate flex-1 text-left">
                  loadstring(game:HttpGet(&quot;https://getgold.cc&quot;))()
                </code>
                <button
                  onClick={copyToClipboard}
                  className="p-1.5 hover:bg-white/10 rounded transition-colors flex-shrink-0"
                  aria-label="Copy to clipboard"
                >
                  <div className="relative w-4 h-4">
                    <Copy
                      className={`w-4 h-4 text-white/70 absolute inset-0 transition-all duration-300 ${
                        copied ? "opacity-0 scale-0 rotate-90" : "opacity-100 scale-100 rotate-0"
                      }`}
                    />
                    <Check
                      className={`w-4 h-4 text-green-400 absolute inset-0 transition-all duration-300 ${
                        copied ? "opacity-100 scale-100 rotate-0" : "opacity-0 scale-0 -rotate-90"
                      }`}
                    />
                  </div>
                </button>
                <a
                  href="https://discord.gg/your-discord"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-1.5 hover:bg-[#5865F2]/20 rounded transition-colors flex-shrink-0 relative overflow-hidden group"
                  aria-label="Join Discord"
                >
                  <svg className="w-5 h-5 text-[#5865F2] relative z-10" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515a.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0a12.64 12.64 0 0 0-.617-1.25a.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057a19.9 19.9 0 0 0 5.993 3.03a.078.078 0 0 0 .084-.028a14.09 14.09 0 0 0 1.226-1.994a.076.076 0 0 0-.041-.106a13.107 13.107 0 0 1-1.872-.892a.077.077 0 0 1-.008-.128a10.2 10.2 0 0 0 .372-.292a.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127a12.299 12.299 0 0 1-1.873.892a.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028a19.839 19.839 0 0 0 6.002-3.03a.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.956-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.955-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.946 2.418-2.157 2.418z" />
                  </svg>
                  <div className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/30 to-transparent skew-x-12 animate-discord-shine" />
                </a>
              </div>
            </div>

            <button
              onClick={handleGetKey}
              className="relative px-8 py-3 bg-gradient-to-r from-[#FFB800] to-[#FFA500] hover:from-[#FFC520] hover:to-[#FFB020] text-black font-bold rounded-lg transition-all hover:shadow-lg hover:shadow-[#FFB800]/50 transform hover:scale-105 active:scale-95 shine-effect"
            >
              Get key
            </button>
            <p className="mt-4 text-sm text-[#FFB800] font-semibold tracking-wide">Keyless every saturday!</p>
          </div>
        </section>
      </BeamsBackground>

      <div
        ref={executorsRef}
        className={`bg-[#0a0a0a] animate-stagger-in stagger-2 scroll-reveal-slide transition-all duration-[1200ms] ${executorsVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
      >
        <ScrollText
          leftText="we support"
          rightPhrases={["Velocity", "Wave", "bunni.lol", "Zenith", "Solara", "Xeno"]}
        />
      </div>

      <div
        ref={gamesRef}
        className={`bg-[#0a0a0a] animate-stagger-in stagger-3 scroll-reveal-slide transition-all duration-[1200ms] ${gamesVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
      >
        <GamesShowcase />
      </div>

      <div
        ref={featuresRef}
        className={`bg-[#0a0a0a] animate-stagger-in stagger-4 scroll-reveal-slide transition-all duration-[1200ms] ${featuresVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
      >
        <FeaturesSection />
      </div>

      <div
        ref={statsRef}
        className={`bg-[#0a0a0a] animate-stagger-in stagger-6 scroll-reveal-slide transition-all duration-[1200ms] ${statsVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
      >
        <MiniShop />
      </div>

      <section
        ref={statsRef}
        className={`py-20 px-4 relative bg-[#0a0a0a] animate-stagger-in stagger-6 scroll-reveal-slide transition-all duration-[1200ms] ${statsVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
      >
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <h2 className="text-3xl font-bold mb-4" style={{ fontFamily: "var(--font-display)" }}>
            Used by over <span className="text-[#FFB800]">100,000+</span> people
          </h2>
          <p className="text-gray-400">
            And even by Kardin Hong <span className="text-xs">youtube.com</span>
          </p>
        </div>
      </section>

      <div
        ref={testimonialsRef}
        className={`bg-[#0a0a0a] animate-stagger-in stagger-7 scroll-reveal-slide transition-all duration-[1200ms] ${testimonialsVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
      >
        <TestimonialsSection />
      </div>

      <div
        ref={faqRef}
        className={`bg-[#0a0a0a] animate-stagger-in stagger-8 scroll-reveal-slide transition-all duration-[1200ms] ${faqVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
      >
        <FAQSection />
      </div>

      <footer className="border-t border-white/10 py-12 px-4 bg-[#0a0a0a]">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center gap-8 mb-8">
            <div className="flex items-center gap-3">
              <Image src="/gold-icon.png" alt="gold" width={24} height={24} className="w-6 h-6" />
              <span className="font-bold" style={{ fontFamily: "var(--font-display)" }}>
                gold
              </span>
            </div>
            <p className="text-gray-400 text-sm text-center">Site made by upio</p>
          </div>

          <div className="flex justify-center mb-8">
            <button className="px-8 py-3 bg-gradient-to-r from-[#FFB800] to-[#FFA500] hover:from-[#FFC520] hover:to-[#FFB020] text-black font-bold rounded-lg transition-all hover:shadow-lg hover:shadow-[#FFB800]/50">
              Get gold
            </button>
          </div>

          <div className="text-center text-gray-500 text-xs space-y-2">
            <p>
              This software is not affiliated, associated, authorized, endorsed by, or in any way officially connected
              with Roblox or Microsoft or any of its subsidiaries or its affiliates.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
