import type React from "react"
import type { Metadata } from "next"
import { Montserrat } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import "./globals.css"

const montserrat = Montserrat({ subsets: ["latin"], weight: ["400", "600", "700", "800"] })

export const metadata: Metadata = {
  title: "gold - The best Roblox script",
  description: "Premium Roblox script for all your favorite games",
  generator: "v0.app",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" style={{ backgroundColor: "#0a0a0a" }}>
      <body className={`${montserrat.className} antialiased`} style={{ backgroundColor: "#0a0a0a" }}>
        {children}
        <Analytics />
      </body>
    </html>
  )
}
