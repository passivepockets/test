"use client"

import { useRouter } from "next/navigation"
import BeamsBackground from "@/components/beams-background"
import { ArrowLeft } from "lucide-react"

export default function KeysPage() {
  const router = useRouter()

  const handlePurchase = () => {
    router.push("/?scroll=mini-shop")

    // Also fallback to direct hash navigation
    setTimeout(() => {
      const miniShopElement = document.getElementById("mini-shop")
      if (miniShopElement) {
        miniShopElement.scrollIntoView({ behavior: "smooth" })
      }
    }, 100)
  }

  return (
    <BeamsBackground intensity="strong" className="bg-[#0a0a0a] min-h-screen animate-page-slide-down">
      <div className="relative z-10 min-h-screen flex flex-col">
        {/* Minimal Header */}
        <header className="backdrop-blur-sm sticky top-0 z-20">
          <div className="max-w-6xl mx-auto px-4 py-6 flex items-center">
            <button
              onClick={() => router.back()}
              className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors duration-300 text-sm"
            >
              <ArrowLeft className="w-4 h-4" />
              back
            </button>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 flex flex-col items-center justify-center px-4 py-12">
          <div className="w-full max-w-4xl">
            {/* Hero Headline */}
            <div className="text-center mb-20 space-y-4">
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-white leading-tight">
                get your free key here!
              </h1>
              <p className="text-lg text-gray-400">select your preferred option</p>
            </div>

            {/* Key Options Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
              {/* Work.ink Card */}
              <div className="group relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-yellow-600/5 to-yellow-700/5 rounded-2xl transition-all duration-500 group-hover:from-yellow-600/10 group-hover:to-yellow-700/10" />
                <div className="relative bg-black/40 backdrop-blur-md border border-yellow-600/20 rounded-2xl p-8 md:p-10 transition-all duration-500 group-hover:border-yellow-500/40">
                  {/* Card Shine Effect */}
                  <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-yellow-600/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

                  <div className="relative space-y-6">
                    <div>
                      <h3 className="text-2xl font-bold text-white mb-2">work.ink</h3>
                      <p className="text-sm text-gray-500">free key by completing tasks</p>
                    </div>

                    <div>
                      <p className="text-5xl font-bold text-yellow-500">free</p>
                    </div>

                    <ul className="space-y-3">
                      {[
                        "no payment required",
                        "easy tasks to complete",
                        "instant key delivery",
                        "full access included",
                      ].map((item, i) => (
                        <li key={i} className="flex items-center gap-3 text-gray-300 text-sm group/item">
                          <span className="text-yellow-500 text-lg">✓</span>
                          <span className="group-hover/item:text-white transition-colors duration-300">{item}</span>
                        </li>
                      ))}
                    </ul>

                    <button className="w-full px-6 py-3 bg-yellow-600/20 border border-yellow-500/40 hover:bg-yellow-600/30 text-yellow-400 font-semibold rounded-xl transition-all duration-300 hover:border-yellow-400/70 shine-effect">
                      go to work.ink
                    </button>
                  </div>
                </div>
              </div>

              {/* Linkvertise Card */}
              <div className="group relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-yellow-600/5 to-yellow-700/5 rounded-2xl transition-all duration-500 group-hover:from-yellow-600/10 group-hover:to-yellow-700/10" />
                <div className="relative bg-black/40 backdrop-blur-md border border-yellow-600/20 rounded-2xl p-8 md:p-10 transition-all duration-500 group-hover:border-yellow-500/40">
                  {/* Card Shine Effect */}
                  <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-yellow-600/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

                  <div className="relative space-y-6">
                    <div>
                      <h3 className="text-2xl font-bold text-white mb-2">linkvertise</h3>
                      <p className="text-sm text-gray-500">free key by watching ads</p>
                    </div>

                    <div>
                      <p className="text-5xl font-bold text-yellow-500">free</p>
                    </div>

                    <ul className="space-y-3">
                      {["no payment required", "quick ad views", "instant key delivery", "full access included"].map(
                        (item, i) => (
                          <li key={i} className="flex items-center gap-3 text-gray-300 text-sm group/item">
                            <span className="text-yellow-500 text-lg">✓</span>
                            <span className="group-hover/item:text-white transition-colors duration-300">{item}</span>
                          </li>
                        ),
                      )}
                    </ul>

                    <button className="w-full px-6 py-3 bg-yellow-600/20 border border-yellow-500/40 hover:bg-yellow-600/30 text-yellow-400 font-semibold rounded-xl transition-all duration-300 hover:border-yellow-400/70 shine-effect">
                      go to linkvertise
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Purchase Prompt Section */}
            <div className="mt-16 pt-8 border-t border-yellow-600/20">
              <div className="flex flex-col items-center justify-center gap-4">
                <p className="text-center text-gray-400">tired of these tasks?</p>
                <button
                  onClick={handlePurchase}
                  className="px-8 py-3 bg-yellow-600/30 border border-yellow-500/50 hover:bg-yellow-600/40 hover:border-yellow-400/70 text-yellow-300 font-semibold rounded-xl transition-all duration-300 shine-effect"
                >
                  purchase a key instead
                </button>
              </div>
            </div>
          </div>
        </main>
      </div>
    </BeamsBackground>
  )
}
