"use client"

import { Check } from "lucide-react"

const games = [
  { name: "Be NPC or DIE", status: "supported" },
  { name: "civilization survival game", status: "supported" },
  { name: "Plants Vs Brainrots", status: "supported" },
  { name: "Dig It", status: "supported" },
  { name: "Grow a Garden", status: "supported" },
  { name: "Prospecting!", status: "supported" },
  { name: "Street Life Remastered", status: "supported" },
  { name: "Creatures of Sonaria", status: "supported" },
  { name: "DIG", status: "supported" },
  { name: "Fish It!", status: "supported" },
]

export function GamesShowcase() {
  return (
    <section className="py-12 px-6">
      <div className="max-w-[1400px] mx-auto">
        <h2 className="text-white text-2xl font-semibold text-center mb-8">games we support</h2>

        <div className="flex flex-wrap justify-center gap-3">
          {games.map((game) => (
            <div
              key={game.name}
              className="relative rounded-xl overflow-hidden border border-white/10 bg-black w-[210px]"
            >
              <div className="aspect-[4/3] relative bg-gradient-to-br from-zinc-900 to-black">
                <img
                  src={`/.jpg?height=160&width=200&query=${game.name}`}
                  alt={game.name}
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="relative p-3 pb-2.5">
                <h3 className="text-white text-sm font-medium leading-tight pr-7">{game.name}</h3>

                <div className="absolute bottom-2.5 right-2.5">
                  {game.status === "supported" ? (
                    <div className="w-5 h-5 rounded-full bg-emerald-500/20 border border-emerald-500 flex items-center justify-center">
                      <Check className="w-3 h-3 text-emerald-400" strokeWidth={3} />
                    </div>
                  ) : (
                    <div className="w-5 h-5 rounded-full bg-amber-500/20 border border-amber-500 flex items-center justify-center">
                      <div className="w-1.5 h-1.5 bg-amber-400 rounded-full" />
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
