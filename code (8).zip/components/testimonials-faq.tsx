"use client"

import { useState } from "react"

const testimonials = [
  {
    name: "User #1",
    text: "Best script ever! Amazing features and support.",
    initials: "U1",
  },
  {
    name: "User #2",
    text: "The UI is so clean and intuitive. Highly recommend!",
    initials: "U2",
  },
  {
    name: "User #3",
    text: "Worth every penny. Great community and updates.",
    initials: "U3",
  },
]

const faqs = [
  {
    q: "How do I get whitelisted? How do I get a free key?",
    a: "Join our Discord server for more information.",
  },
  {
    q: "Where can I report bugs and suggest features?",
    a: "Use the #bugs and #suggestions channels in Discord.",
  },
  { q: "Does this work on mobile?", a: "gold is designed for PC only." },
  { q: "I can't close the GUI. How can I fix it?", a: "Press the assigned keybind or restart your game." },
  { q: "What games are supported?", a: "Check our website for the full list of supported games." },
  { q: "How do I review the script?", a: "Leave a review in our Discord community." },
]

export function TestimonialsSection() {
  return (
    <section className="py-20 px-4 relative">
      <div className="max-w-4xl mx-auto">
        <h2
          className="text-3xl font-bold text-center mb-12 text-balance animate-fade-in"
          style={{ fontFamily: "var(--font-display)" }}
        >
          Here's what people say about gold
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((testimonial, i) => (
            <div
              key={i}
              className="p-6 bg-gradient-to-br from-white/10 to-white/5 border border-white/10 hover:border-white/20 rounded-lg transition-all group hover:-translate-y-1"
              style={{
                animation: `fadeInUp 0.4s ease-out ${i * 0.1}s both`,
              }}
            >
              <p className="text-gray-300 mb-4 italic">"{testimonial.text}"</p>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-[#FFB800] to-[#FFA500] rounded-full flex items-center justify-center text-sm font-semibold text-black">
                  {testimonial.initials}
                </div>
                <p className="font-semibold text-sm">{testimonial.name}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(null)

  return (
    <section className="py-20 px-4 relative">
      <div className="absolute inset-0 opacity-20">
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-[#FFB800]/25 rounded-full blur-3xl" />
      </div>

      <div className="max-w-4xl mx-auto relative z-10">
        <h2
          className="text-3xl font-bold text-center mb-4 animate-fade-in"
          style={{ fontFamily: "var(--font-display)" }}
        >
          FAQ
        </h2>
        <p className="text-center text-gray-400 mb-12 animate-fade-in" style={{ animationDelay: "0.1s" }}>
          The full FAQ is in the{" "}
          <a href="#" className="text-[#FFB800] hover:text-[#FFC520] transition">
            Discord Server
          </a>
        </p>

        <div className="space-y-4">
          {faqs.map((faq, i) => (
            <div
              key={i}
              className="group p-6 bg-gradient-to-r from-white/5 to-white/2 border border-white/10 hover:border-white/20 rounded-lg cursor-pointer transition-all"
              style={{
                animation: `fadeInUp 0.3s ease-out ${i * 0.05}s both`,
              }}
              onClick={() => setOpenIndex(openIndex === i ? null : i)}
            >
              <div className="flex justify-between items-center font-semibold select-none">
                <span className="text-lg">{faq.q}</span>
                <span
                  className="text-[#FFB800] transition-transform duration-300"
                  style={{
                    transform: openIndex === i ? "rotate(180deg)" : "rotate(0deg)",
                  }}
                >
                  ▼
                </span>
              </div>
              {openIndex === i && (
                <div
                  className="text-gray-400 mt-4 overflow-hidden"
                  style={{
                    animation: `fadeInUp 0.2s ease-out forwards`,
                  }}
                >
                  {faq.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
