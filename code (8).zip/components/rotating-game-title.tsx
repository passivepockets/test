"use client"

import { useState, useEffect } from "react"

const games = [
  "Be NPC or DIE",
  "civilization survival game",
  "Plants Vs Brainrots",
  "Dig it",
  "Grow a Garden",
  "Prospecting!",
  "Street Life Remastered",
  "Creatures of Sonaria",
  "Fish it!",
]

export function RotatingGameTitle() {
  const [currentGameIndex, setCurrentGameIndex] = useState(0)
  const [displayedText, setDisplayedText] = useState("")
  const [isDeleting, setIsDeleting] = useState(false)

  useEffect(() => {
    const currentGame = games[currentGameIndex]
    const typingSpeed = isDeleting ? 30 : 50
    const delayBetweenGames = 2000

    const timeout = setTimeout(() => {
      if (!isDeleting) {
        if (displayedText.length < currentGame.length) {
          setDisplayedText(currentGame.slice(0, displayedText.length + 1))
        } else {
          setTimeout(() => setIsDeleting(true), delayBetweenGames)
        }
      } else {
        if (displayedText.length > 0) {
          setDisplayedText(displayedText.slice(0, -1))
        } else {
          setIsDeleting(false)
          setCurrentGameIndex((prev) => (prev + 1) % games.length)
        }
      }
    }, typingSpeed)

    return () => clearTimeout(timeout)
  }, [displayedText, isDeleting, currentGameIndex])

  return (
    <span className="bg-gradient-to-r from-[#FFB800] to-[#FFA500] bg-clip-text text-transparent">
      {displayedText}
      <span className="animate-pulse">|</span>
    </span>
  )
}
