"use client"

import { useState, useEffect } from "react"

export function LaptopMockup() {
  const [scrollY, setScrollY] = useState(0)

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY)
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <div className="relative w-full max-w-4xl mx-auto">
      <div
        className="relative transition-transform duration-300"
        style={{
          transform: `perspective(1200px) rotateX(${Math.min(scrollY * 0.03, 15)}deg) rotateY(${Math.min(scrollY * 0.02, 10)}deg)`,
        }}
      >
        <div className="relative rounded-2xl overflow-hidden shadow-2xl border-4 border-gray-900 bg-gray-900">
          <div className="relative aspect-video bg-black overflow-hidden">
            <img src="/roblox-doors-game-interface.jpg" alt="" className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-br from-white/10 via-transparent to-transparent pointer-events-none" />
          </div>

          <div className="h-12 bg-gradient-to-b from-gray-800 to-gray-900" />
        </div>

        <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 w-4/5 h-6 bg-black/20 rounded-full blur-xl" />
      </div>
    </div>
  )
}
