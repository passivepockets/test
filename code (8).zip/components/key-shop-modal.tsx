"use client"

interface KeyShopModalProps {
  isOpen: boolean
  onClose: () => void
}

export function KeyShopModal({ isOpen, onClose }: KeyShopModalProps) {
  return (
    <>
      {/* Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 transition-opacity duration-300"
          onClick={onClose}
        />
      )}

      {/* Modal */}
      <div
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ease-out ${
          isOpen ? "translate-y-0 opacity-100" : "-translate-y-full opacity-0"
        }`}
      >
        <div className="bg-gradient-to-b from-black via-gray-950 to-black border-b border-[#FFB800]/30 shadow-2xl relative overflow-hidden">
          {/* Pattern overlay */}
          <div className="absolute inset-0 opacity-5">
            <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                  <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="0.5" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid)" />
            </svg>
          </div>

          {/* Subtle gradient blobs */}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-[#FFB800] to-[#FFA500] rounded-full blur-3xl"></div>
            <div className="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-tr from-[#FFBF00] to-[#FFA500] rounded-full blur-3xl"></div>
          </div>

          <div className="max-w-4xl mx-auto px-4 py-12 relative z-10">
            {/* Close Button */}
            <button
              onClick={onClose}
              className="absolute top-4 right-4 text-gray-500 hover:text-white transition text-2xl"
            >
              ✕
            </button>

            <h2
              className="text-4xl font-bold text-center mb-2 text-white"
              style={{ fontFamily: "var(--font-display)" }}
            >
              get your free key
            </h2>
            <p className="text-center text-gray-400 mb-12">don&#39;t wanna do all these steps? purchase a key at our shop!       </p>

            <div className="grid md:grid-cols-2 gap-8 mb-12">
              {/* Work.ink Option */}
              <a
                href="https://work.ink"
                target="_blank"
                rel="noopener noreferrer"
                onClick={onClose}
                className="bg-gray-950/50 border border-gray-800/50 rounded-xl p-8 hover:border-[#FFB800]/50 transition-all duration-500 hover:bg-gray-950/70 backdrop-blur cursor-pointer group"
              >
                <h3 className="text-2xl font-bold text-white mb-2" style={{ fontFamily: "var(--font-display)" }}>
                  work.ink
                </h3>
                <p className="text-[#FFB800]/70 text-sm mb-6">Free key by completing tasks</p>
                <div className="text-4xl font-bold text-white mb-8">FREE</div>
                <ul className="space-y-3 mb-8 text-gray-300 text-sm">
                  <li className="flex items-center gap-2">
                    <span className="text-[#FFB800]">✓</span>
                    <span>No payment required</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-[#FFB800]">✓</span>
                    <span>Easy tasks to complete</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-[#FFB800]">✓</span>
                    <span>Instant key delivery</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-[#FFB800]">✓</span>
                    <span>Full access included</span>
                  </li>
                </ul>
                <div className="px-6 py-3 bg-gray-700 group-hover:bg-[#FFB800] group-hover:text-black text-white font-bold rounded-lg transition-all text-center relative overflow-hidden">
                  <div
                    className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -skew-x-12 animate-pulse"
                    style={{
                      animation: "shine 3s infinite",
                    }}
                  />
                  <span className="relative">Go to work.ink</span>
                </div>
              </a>

              {/* Discord/Second Free Option */}
              <a
                href="https://discord.gg/your-discord"
                target="_blank"
                rel="noopener noreferrer"
                onClick={onClose}
                className="bg-gray-950/50 border border-gray-800/50 rounded-xl p-8 hover:border-[#FFB800]/50 transition-all duration-500 hover:bg-gray-950/70 backdrop-blur cursor-pointer group"
              >
                <h3 className="text-2xl font-bold text-white mb-2" style={{ fontFamily: "var(--font-display)" }}>
                  Discord
                </h3>
                <p className="text-[#FFB800]/70 text-sm mb-6">Free key from our community</p>
                <div className="text-4xl font-bold text-white mb-8">FREE</div>
                <ul className="space-y-3 mb-8 text-gray-300 text-sm">
                  <li className="flex items-center gap-2">
                    <span className="text-[#FFB800]">✓</span>
                    <span>No payment required</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-[#FFB800]">✓</span>
                    <span>Join our community</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-[#FFB800]">✓</span>
                    <span>Get instant support</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-[#FFB800]">✓</span>
                    <span>Full access included</span>
                  </li>
                </ul>
                <div className="px-6 py-3 bg-gray-700 group-hover:bg-[#FFB800] group-hover:text-black text-white font-bold rounded-lg transition-all text-center relative overflow-hidden">
                  <div
                    className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -skew-x-12 animate-pulse"
                    style={{
                      animation: "shine 3s infinite",
                    }}
                  />
                  <span className="relative">Join Discord</span>
                </div>
              </a>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
