"use client"

import { useState } from "react"

interface PricingModalProps {
  isOpen: boolean
  onClose: () => void
}

export function PricingModal({ isOpen, onClose }: PricingModalProps) {
  const [selectedTier, setSelectedTier] = useState<"weekly" | "monthly" | "yearly">("monthly")
  const [slideDirection, setSlideDirection] = useState<"left" | "right">("right")

  const shinyGoldPrices = {
    weekly: "$4.99",
    monthly: "$14.99",
    yearly: "$149.99",
  }

  const tierOrder = ["weekly", "monthly", "yearly"]

  const handleTierChange = (tier: "weekly" | "monthly" | "yearly") => {
    const currentIndex = tierOrder.indexOf(selectedTier)
    const newIndex = tierOrder.indexOf(tier)
    setSlideDirection(newIndex > currentIndex ? "right" : "left")
    setSelectedTier(tier)
  }

  return (
    <>
      {/* Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 transition-opacity duration-300"
          onClick={onClose}
        />
      )}

      {/* Modal */}
      <div
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ease-out ${
          isOpen ? "translate-y-0 opacity-100" : "-translate-y-full opacity-0"
        }`}
      >
        <div className="bg-gradient-to-b from-black via-gray-950 to-black border-b border-[#FFB800]/30 shadow-2xl relative overflow-hidden">
          {/* Pattern overlay */}
          <div className="absolute inset-0 opacity-5">
            <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                  <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="0.5" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid)" />
            </svg>
          </div>

          {/* Subtle gradient blobs */}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-[#FFB800] to-[#FFA500] rounded-full blur-3xl"></div>
            <div className="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-tr from-[#FFBF00] to-[#FFA500] rounded-full blur-3xl"></div>
          </div>

          <div className="max-w-4xl mx-auto px-4 py-12 relative z-10">
            {/* Close Button */}
            <button
              onClick={onClose}
              className="absolute top-4 right-4 text-gray-500 hover:text-white transition text-2xl"
            >
              ✕
            </button>

            <h2
              className="text-4xl font-bold text-center mb-2 text-white"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Choose Your Plan
            </h2>
            <p className="text-center text-gray-400 mb-12">Select the perfect plan for your needs</p>

            <div className="grid md:grid-cols-2 gap-8 mb-12">
              {/* Regular Lifetime */}
              <div className="bg-gray-950/50 border border-gray-800/50 rounded-xl p-8 hover:border-gray-700 transition-all duration-500 hover:bg-gray-950/70 backdrop-blur">
                <h3 className="text-2xl font-bold text-white mb-2" style={{ fontFamily: "var(--font-display)" }}>
                  gold regular
                </h3>
                <p className="text-[#FFB800]/70 text-sm mb-6">Lifetime access</p>
                <div className="text-4xl font-bold text-white mb-8">$49.99</div>
                <ul className="space-y-3 mb-8 text-gray-300 text-sm">
                  <li className="flex items-center gap-2">
                    <span className="text-[#FFB800]">✓</span>
                    <span>Full lifetime access</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-[#FFB800]">✓</span>
                    <span>All standard features</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-[#FFB800]">✓</span>
                    <span>Community support</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-[#FFB800]">✓</span>
                    <span>Regular updates</span>
                  </li>
                </ul>
                <button className="w-full px-6 py-3 bg-[#FFB800] hover:bg-[#FFC520] text-black font-bold rounded-lg transition-all hover:shadow-lg hover:shadow-[#FFB800]/30">
                  Get Regular
                </button>
              </div>

              {/* Shiny Gold */}
              <div className="bg-gray-950/50 border border-[#FFB800]/40 rounded-xl p-8 hover:border-[#FFB800] transition-all duration-500 backdrop-blur relative overflow-hidden group">
                <div className="absolute top-0 right-0 bg-gradient-to-l from-[#FFB800]/30 to-transparent px-4 py-2 rounded-bl-lg">
                  <span className="text-[#FFB800] text-xs font-bold">POPULAR</span>
                </div>

                <h3 className="text-2xl font-bold text-white mb-2" style={{ fontFamily: "var(--font-display)" }}>
                  shiny gold
                </h3>
                <p className="text-[#FFB800]/70 text-sm mb-6">Premium features & priority support</p>

                {/* Tier Selector */}
                <div className="flex gap-2 mb-8 bg-black/60 p-2 rounded-lg border border-gray-800/50">
                  {(["weekly", "monthly", "yearly"] as const).map((tier) => (
                    <button
                      key={tier}
                      onClick={() => handleTierChange(tier)}
                      className={`flex-1 px-3 py-2 rounded transition text-sm font-medium ${
                        selectedTier === tier ? "bg-[#FFB800] text-black" : "text-gray-400 hover:text-white"
                      }`}
                    >
                      {tier.charAt(0).toUpperCase() + tier.slice(1)}
                    </button>
                  ))}
                </div>

                <div className="relative min-h-32">
                  <div
                    key={selectedTier}
                    className={`transition-all duration-500 ease-out ${
                      slideDirection === "right" ? "animate-slide-in-right" : "animate-slide-in-left"
                    }`}
                  >
                    <div className="text-4xl font-bold text-white mb-8">{shinyGoldPrices[selectedTier]}</div>

                    <ul className="space-y-3 mb-8 text-gray-300 text-sm">
                      <li className="flex items-center gap-2">
                        <span className="text-[#FFB800]">✓</span>
                        <span>Everything in Regular</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <span className="text-[#FFB800]">✓</span>
                        <span>Advanced features</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <span className="text-[#FFB800]">✓</span>
                        <span>Priority support</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <span className="text-[#FFB800]">✓</span>
                        <span>Early access to updates</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <span className="text-[#FFB800]">✓</span>
                        <span>Exclusive perks</span>
                      </li>
                    </ul>
                  </div>
                </div>

                <button className="w-full px-6 py-3 bg-gradient-to-r from-[#FFB800] to-[#FFA500] hover:from-[#FFC520] hover:to-[#FFB020] text-black font-bold rounded-lg transition-all hover:shadow-lg hover:shadow-[#FFB800]/40">
                  Get Shiny Gold
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
