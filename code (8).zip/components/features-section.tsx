"use client"

import { useMemo } from "react"
import { useForcedScroll } from "@/hooks/use-forced-scroll"
import { Obsidian } from "@/components/obsidian/obsidian"
import UIData from "@/components/demo/ObsidianExtracted.json"

export function FeaturesSection() {
  const memoizedObsidian = useMemo(
    () => <Obsidian title="mspaint" icon="/mspaint.jpg" footer="version: example" uiData={UIData} />,
    [],
  )

  const { scrollProgress, containerRef } = useForcedScroll()

  const uiTransform = {
    transform: `translateX(${scrollProgress * 300}px)`,
    transition: "transform 0.1s cubic-bezier(0.25, 0.46, 0.45, 0.94)",
  }

  const textTransform = {
    transform: `translateX(${-scrollProgress * 400}px)`,
    transition: "transform 0.1s cubic-bezier(0.25, 0.46, 0.45, 0.94)",
  }

  return (
    <section className="py-20 px-4 relative overflow-hidden" ref={containerRef}>
      <div className="max-w-4xl mx-auto">
        <h2
          className="text-3xl font-bold text-center mb-12 text-balance animate-fade-in"
          style={{ fontFamily: "var(--font-display)" }}
        >
          gold features
        </h2>

        <div className="relative flex justify-center items-center h-[600px]">
          {/* Hidden text layer - fixed width, centered, behind UI */}
          <div
            className="absolute left-1/2 -translate-x-1/2 w-96 text-center text-base font-semibold text-white pointer-events-none"
            style={textTransform}
          >
            every feature has been crafted to <span className="text-[#FFB800]">perfection</span>, ensuring while using
            this script, you are always one step ahead
          </div>

          {/* UI layer - slides over the text */}
          <div
            className="max-w-[720px] max-h-[600px] scale-[0.8] max-sm:scale-[0.5] md:scale-90 lg:scale-100 relative z-10"
            style={uiTransform}
          >
            {memoizedObsidian}
          </div>
        </div>
      </div>
    </section>
  )
}
