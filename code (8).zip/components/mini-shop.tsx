"use client"

import { useState } from "react"
import { Check } from "lucide-react"

export function MiniShop() {
  const [selectedShinyTier, setSelectedShinyTier] = useState<"weekly" | "monthly" | "yearly">("monthly")
  const [slideDirection, setSlideDirection] = useState<"left" | "right">("right")

  const lifetimeTier = {
    name: "gold lifetime",
    price: "$3",
    description: "one-time payment",
    features: ["all basic features", "lifetime access", "one-time payment", "community support"],
  }

  const shinyGoldTiers = {
    weekly: {
      name: "gold shiny",
      price: "$4.99",
      description: "per week",
      badge: null,
      badgeColor: "",
      features: [
        "everything in regular",
        "advanced features",
        "priority support",
        "early access to updates",
        "exclusive perks",
      ],
    },
    monthly: {
      name: "gold shiny",
      price: "$14.99",
      description: "per month",
      badge: "most popular",
      badgeColor: "bg-yellow-600",
      features: [
        "everything in regular",
        "advanced features",
        "priority support",
        "early access to updates",
        "exclusive perks",
      ],
    },
    yearly: {
      name: "gold shiny",
      price: "$149.99",
      description: "per year",
      badge: "save 50%",
      badgeColor: "bg-yellow-500",
      features: [
        "everything in regular",
        "advanced features",
        "priority support",
        "early access to updates",
        "exclusive perks",
      ],
    },
  }

  const tierOrder: Array<"weekly" | "monthly" | "yearly"> = ["weekly", "monthly", "yearly"]

  const handleTierChange = (tier: "weekly" | "monthly" | "yearly") => {
    const currentIndex = tierOrder.indexOf(selectedShinyTier)
    const newIndex = tierOrder.indexOf(tier)
    setSlideDirection(newIndex > currentIndex ? "right" : "left")
    setSelectedShinyTier(tier)
  }

  const currentShinyTier = shinyGoldTiers[selectedShinyTier]

  return (
    <section id="mini-shop" className="py-24 px-4 relative bg-[#0a0a0a] overflow-hidden scroll-smooth">
      {/* Subtle background elements */}
      <div className="fixed top-0 left-0 right-0 pointer-events-none opacity-15 z-0">
        <div className="absolute -top-48 right-0 w-96 h-96 bg-[#DAA520] rounded-full blur-3xl" />
        <div className="absolute -top-48 -left-48 w-96 h-96 bg-[#CD853F] rounded-full blur-3xl" />
      </div>

      <div className="max-w-6xl mx-auto relative z-10">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-3 text-white" style={{ fontFamily: "var(--font-display)" }}>
            upgrade your gold
          </h2>
          <p className="text-gray-400 text-lg">choose between lifetime access or premium subscriptions</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 lg:gap-12 items-start">
          <div className="relative bg-black/40 border border-yellow-700/50 rounded-xl p-8 md:p-10 backdrop-blur-sm overflow-hidden group w-full transition-all duration-500 hover:border-yellow-600/70">
            <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-yellow-600/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

            {/* Content */}
            <div className="relative z-10">
              {/* Header */}
              <div className="mb-8">
                <h3 className="text-2xl font-bold text-white mb-1">{lifetimeTier.name}</h3>
                <p className="text-gray-500 text-sm">{lifetimeTier.description}</p>
              </div>

              {/* Price */}
              <div className="mb-8">
                <div className="flex items-baseline gap-1">
                  <span className="text-5xl font-bold text-yellow-600">{lifetimeTier.price}</span>
                </div>
              </div>

              {/* Features */}
              <ul className="space-y-3 mb-8">
                {lifetimeTier.features.map((feature, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                    <span className="text-gray-400 text-sm">{feature}</span>
                  </li>
                ))}
              </ul>

              {/* CTA Button */}
              <button className="w-full px-6 py-3 bg-yellow-700/25 border border-yellow-600/60 hover:bg-yellow-700/35 text-yellow-200 font-semibold rounded-lg transition-all duration-300 hover:border-yellow-500/80 group/btn relative overflow-hidden">
                <div
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -skew-x-12 animate-pulse"
                  style={{
                    animation: "shine 3s infinite",
                  }}
                />
                <span className="relative">get {lifetimeTier.name}</span>
              </button>
            </div>
          </div>

          <div className="relative bg-black/60 border border-yellow-700/50 rounded-xl p-8 md:p-10 backdrop-blur-sm overflow-hidden group w-full transition-all duration-500 hover:border-yellow-600/70">
            {currentShinyTier.badge && (
              <div className="absolute top-4 right-4">
                <div
                  className={`px-3 py-1 text-xs font-bold text-white ${currentShinyTier.badgeColor === "bg-yellow-500" ? "bg-yellow-600" : "bg-yellow-500"} rounded-full`}
                >
                  {currentShinyTier.badge}
                </div>
              </div>
            )}

            <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-yellow-600/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

            {/* Content */}
            <div className="relative z-10">
              {/* Tier Selector - INSIDE Modal */}
              <div className="flex justify-center mb-6">
                <div className="inline-flex gap-2 bg-black/50 border border-yellow-700/30 rounded-lg p-1 backdrop-blur-sm">
                  {(["weekly", "monthly", "yearly"] as const).map((tier) => (
                    <button
                      key={tier}
                      onClick={() => handleTierChange(tier)}
                      className={`px-4 py-1.5 rounded-md transition-all duration-300 text-xs md:text-sm font-semibold ${
                        selectedShinyTier === tier
                          ? "bg-yellow-700/40 text-yellow-200 border border-yellow-600/60"
                          : "text-gray-500 border border-transparent hover:text-gray-300"
                      }`}
                    >
                      {tier}
                    </button>
                  ))}
                </div>
              </div>

              {/* Slide Transition Animations for Content Changes */}
              <div
                key={selectedShinyTier}
                className={`transition-all duration-500 ${slideDirection === "right" ? "animate-in slide-in-from-left-4 fade-in" : "animate-in slide-in-from-right-4 fade-in"}`}
              >
                {/* Header */}
                <div className="mb-8">
                  <h3 className="text-2xl font-bold text-white mb-1">
                    {currentShinyTier.name.split(" ").map((word, i) => (
                      <span key={i} className={word === "shiny" ? "shine-text" : ""}>
                        {word}
                        {i === 0 ? " " : ""}
                      </span>
                    ))}
                  </h3>
                  <p className="text-gray-500 text-sm">{currentShinyTier.description}</p>
                </div>

                {/* Price */}
                <div className="mb-8">
                  <div className="flex items-baseline gap-1">
                    <span className="text-5xl font-bold text-yellow-600">{currentShinyTier.price}</span>
                  </div>
                </div>

                {/* Features */}
                <ul className="space-y-3 mb-8">
                  {currentShinyTier.features.map((feature, i) => (
                    <li key={i} className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-400 text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* CTA Button */}
              <button className="w-full px-6 py-3 bg-yellow-700/35 border border-yellow-600/70 hover:bg-yellow-700/45 text-yellow-100 font-semibold rounded-lg transition-all duration-300 hover:border-yellow-500/80 group/btn relative overflow-hidden">
                <div
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -skew-x-12 animate-pulse"
                  style={{
                    animation: "shine 3s infinite",
                  }}
                />
                <span className="relative">get {currentShinyTier.name}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
