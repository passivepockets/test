"use client"

import { useScrollDirection } from "@/hooks/use-scroll-direction"
import { useEffect, useState, useRef } from "react"

interface ScrollTextProps {
  leftText: string
  rightPhrases: string[]
  className?: string
}

export function ScrollText({ leftText, rightPhrases, className = "" }: ScrollTextProps) {
  const { scrollDirection, scrollY } = useScrollDirection()
  const [activeIndex, setActiveIndex] = useState(0)
  const [internalScroll, setInternalScroll] = useState(0)
  const containerRef = useRef<HTMLDivElement>(null)
  const [isClient, setIsClient] = useState(false)

  useEffect(() => {
    setIsClient(true)
  }, [])

  useEffect(() => {
    if (!isClient) return

    const handleWheel = (e: WheelEvent) => {
      if (!containerRef.current) return

      const rect = containerRef.current.getBoundingClientRect()
      const viewportHeight = window.innerHeight
      const componentHeight = rect.height

      const componentCenter = rect.top + componentHeight / 2
      const viewportCenter = viewportHeight / 2
      const distanceFromCenter = Math.abs(componentCenter - viewportCenter)
      const maxDistance = viewportHeight * 0.2

      const isCentered = distanceFromCenter < maxDistance

      if (isCentered) {
        const currentProgress = internalScroll / 100
        const maxProgress = rightPhrases.length - 1

        if ((e.deltaY > 0 && currentProgress >= maxProgress) || (e.deltaY < 0 && currentProgress <= 0)) {
          return
        }

        e.preventDefault()

        setInternalScroll((prev) => {
          const newScroll = prev + e.deltaY * 0.5
          const maxScroll = (rightPhrases.length - 1) * 100
          return Math.max(0, Math.min(maxScroll, newScroll))
        })
      }
    }

    window.addEventListener("wheel", handleWheel, { passive: false })
    return () => {
      window.removeEventListener("wheel", handleWheel)
    }
  }, [rightPhrases.length, internalScroll, isClient])

  useEffect(() => {
    const newIndex = Math.floor(internalScroll / 100)
    setActiveIndex(Math.max(0, Math.min(rightPhrases.length - 1, newIndex)))
  }, [internalScroll, rightPhrases.length])

  if (!isClient) {
    return (
      <div
        className={`min-h-[60vh] flex items-center gap-6 px-8 py-16 max-lg:gap-4 max-lg:px-6 max-lg:py-12 ${className}`}
      >
        <div className="flex-shrink-0">
          <h1 className="text-4xl max-lg:text-3xl font-medium text-white leading-none">{leftText}</h1>
        </div>
        <div className="flex-1 relative h-[50vh] max-lg:h-[40vh] overflow-hidden">
          {rightPhrases.map((phrase, index) => {
            const isLastPhrase = index === rightPhrases.length - 1
            return (
              <div
                key={phrase}
                className={`text-4xl max-lg:text-3xl font-medium leading-none absolute whitespace-nowrap transition-all duration-500 ease-in-out ${
                  index === 0
                    ? "text-[#FFB800] opacity-100"
                    : isLastPhrase
                      ? "text-gray-500 opacity-0"
                      : "text-gray-500 opacity-60"
                }`}
                style={{
                  transform: `translateY(${index * 60}px)`,
                }}
              >
                {phrase}
              </div>
            )
          })}
        </div>
        <div className="absolute top-0 left-0 right-0 h-32 max-lg:h-24 bg-gradient-to-b from-[#0a0a0a] via-[#0a0a0a]/80 to-transparent pointer-events-none z-10" />
        <div className="absolute bottom-0 left-0 right-0 h-32 max-lg:h-24 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a]/80 to-transparent pointer-events-none z-10" />
      </div>
    )
  }

  return (
    <div
      ref={containerRef}
      className={`min-h-[80vh] flex flex-col items-center justify-center gap-12 px-8 py-16 max-lg:gap-8 max-lg:px-6 max-lg:py-12 ${className}`}
    >
      <div className="w-full flex items-center gap-6 max-lg:gap-4">
        <div className="flex-shrink-0">
          <h1 className="text-4xl max-lg:text-3xl font-medium text-white leading-none">{leftText}</h1>
        </div>

        <div className="flex-1 relative h-[50vh] max-lg:h-[40vh] overflow-hidden">
          <div className="absolute inset-0 flex items-center gap-12 max-lg:gap-6">
            {/* Scrolling text on the left */}
            <div className="flex-shrink-0 w-64 max-lg:w-48 relative h-full">
              <div className="absolute inset-0 flex flex-col justify-center">
                {rightPhrases.map((phrase, index) => {
                  const offset = (index - activeIndex) * (isClient && window.innerWidth < 1024 ? 50 : 60)
                  const isActive = index === activeIndex
                  const isLastPhrase = index === rightPhrases.length - 1
                  const shouldFadeIn = isLastPhrase && isActive

                  return (
                    <div
                      key={phrase}
                      className={`text-4xl max-lg:text-3xl font-medium leading-none absolute whitespace-nowrap transition-all duration-700 ease-in-out ${
                        isActive ? "text-[#FFB800]" : "text-gray-500"
                      } ${
                        isLastPhrase
                          ? shouldFadeIn
                            ? "opacity-100"
                            : "opacity-0"
                          : isActive
                            ? "opacity-100"
                            : "opacity-60"
                      }`}
                      style={{
                        transform: `translateY(${offset}px)`,
                      }}
                    >
                      {phrase}
                    </div>
                  )
                })}
              </div>
            </div>

            {/* Statistics grid on the right */}
            <div className="flex-1 grid grid-cols-2 gap-6 max-lg:gap-4 max-lg:grid-cols-1">
              <div className="flex flex-col items-start justify-center p-6 rounded-lg bg-white/5 border border-white/10 backdrop-blur-sm">
                <div className="text-5xl max-lg:text-4xl font-bold text-[#FFB800] mb-2">4.9★</div>
                <div className="text-base text-gray-300 font-medium">average rating </div>
                <div className="text-sm text-gray-500 mt-1">across all scripts </div>
              </div>

              <div className="flex flex-col items-start justify-center p-6 rounded-lg bg-white/5 border border-white/10 backdrop-blur-sm">
                <div className="text-5xl max-lg:text-4xl font-bold text-[#FFB800] mb-2">100K+</div>
                <div className="text-base text-gray-300 font-medium">active users</div>
                <div className="text-sm text-gray-500 mt-1">monthly executions </div>
              </div>

              <div className="flex flex-col items-start justify-center p-6 rounded-lg bg-white/5 border border-white/10 backdrop-blur-sm">
                <div className="text-5xl max-lg:text-4xl font-bold text-[#FFB800] mb-2">10+</div>
                <div className="text-base text-gray-300 font-medium">scripts available </div>
                <div className="text-sm text-gray-500 mt-1">constantly up-to-date</div>
              </div>

              <div className="flex flex-col items-start justify-center p-6 rounded-lg bg-white/5 border border-white/10 backdrop-blur-sm">
                <div className="text-5xl max-lg:text-4xl font-bold text-[#FFB800] mb-2">100%</div>
                <div className="text-base text-gray-300 font-medium">uptime</div>
                <div className="text-sm text-gray-500 mt-1">reliable 24/7 service</div>
              </div>
            </div>
          </div>

          <div className="absolute top-0 left-0 right-0 h-32 max-lg:h-24 bg-gradient-to-b from-[#0a0a0a] via-[#0a0a0a]/80 to-transparent pointer-events-none z-10" />
          <div className="absolute bottom-0 left-0 right-0 h-32 max-lg:h-24 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a]/80 to-transparent pointer-events-none z-10" />
        </div>
      </div>

      <div className="max-w-4xl mx-auto text-center">
        <p className="text-xl max-lg:text-lg text-gray-300 leading-relaxed animate-stagger-in stagger-2 transition-all duration-[1200ms] opacity-100 translate-y-0">
          gold is where you find it  
        </p>
      </div>
    </div>
  )
}
