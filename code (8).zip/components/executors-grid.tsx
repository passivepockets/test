"use client"

const executors = [
  { name: "Zenith", icon: "⭕", color: "from-purple-500 to-pink-500" },
  { name: "Seliware", icon: "S", color: "from-blue-500 to-cyan-500" },
  { name: "Nucleus", icon: "N", color: "from-indigo-500 to-purple-500" },
  { name: "Solara", icon: "☀️", color: "from-[#FFB800] to-[#FFA500]" },
  { name: "Delta", icon: "Δ", color: "from-green-500 to-teal-500" },
]

export function ExecutorsGrid() {
  return (
    <section className="py-20 px-4 relative">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold text-center mb-4 animate-fade-in">Supporting your favorite executors</h2>
        <p className="text-gray-400 text-center mb-12 animate-fade-in" style={{ animationDelay: "0.1s" }}>
          Compatible with all major Roblox script executors
        </p>

        <div className="flex flex-wrap justify-center gap-8 mb-8">
          {executors.map((executor, i) => (
            <a
              key={executor.name}
              href="#"
              className="flex items-center gap-3 px-6 py-3 bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/30 rounded-lg transition-all group relative overflow-hidden hover:scale-105"
              style={{
                animation: `fadeInUp 0.4s ease-out ${i * 0.05}s both`,
              }}
            >
              <div
                className={`absolute inset-0 bg-gradient-to-r ${executor.color} opacity-0 group-hover:opacity-10 transition-opacity duration-300`}
              />

              <div className="relative z-10">
                <span className="text-xl font-bold group-hover:scale-125 transition-transform duration-300 inline-block">
                  {executor.icon}
                </span>
              </div>
              <span className="text-sm text-gray-300 group-hover:text-white transition relative z-10 font-medium">
                {executor.name}
              </span>
            </a>
          ))}
        </div>
        <p className="text-center text-gray-500 text-sm animate-fade-in" style={{ animationDelay: "0.3s" }}>
          And many more...
        </p>
      </div>
    </section>
  )
}
