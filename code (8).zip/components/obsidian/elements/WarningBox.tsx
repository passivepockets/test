"use client"

import type { FC } from "react"
import { AlertTriangle } from "lucide-react"

interface WarningBoxProps {
  text: string
  title?: string
  visible?: boolean
  isNormal?: boolean
  lockSize?: boolean
}

const ObsidianWarningBox: FC<WarningBoxProps> = ({ text, title = "Warning", visible = true, isNormal = false }) => {
  if (!visible) return null

  return (
    <div
      className={`mb-4 rounded-lg border p-4 ${isNormal ? "border-blue-500/50 bg-blue-500/10" : "border-yellow-500/50 bg-yellow-500/10"}`}
    >
      <div className="flex items-start gap-3">
        <AlertTriangle className={`h-5 w-5 flex-shrink-0 ${isNormal ? "text-blue-400" : "text-yellow-400"}`} />
        <div className="flex-1">
          <h4 className="font-semibold text-white mb-1">{title}</h4>
          <p className="text-sm text-white/80">{text}</p>
        </div>
      </div>
    </div>
  )
}

export default ObsidianWarningBox
