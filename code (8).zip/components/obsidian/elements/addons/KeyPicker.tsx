"use client"

import { type FC, useState } from "react"
import { useUIValue } from "../../UIStateProvider"
import { cn } from "@/lib/utils"

interface KeyPickerProps {
  defaultValue?: string
  className?: string
  stateKey: string
}

const KeyPicker: FC<KeyPickerProps> = ({ defaultValue = "None", className, stateKey }) => {
  const [value, setValue] = useUIValue(stateKey, defaultValue)
  const [isListening, setIsListening] = useState(false)

  const handleClick = () => {
    setIsListening(true)
    const handleKeyDown = (e: KeyboardEvent) => {
      e.preventDefault()
      setValue(e.key)
      setIsListening(false)
      window.removeEventListener("keydown", handleKeyDown)
    }
    window.addEventListener("keydown", handleKeyDown)
  }

  return (
    <button
      onClick={handleClick}
      className={cn(
        "rounded border border-white/20 bg-white/5 px-3 py-1 text-xs text-white/90 hover:bg-white/10",
        isListening && "border-blue-500 bg-blue-500/20",
        className,
      )}
    >
      {isListening ? "Press any key..." : value}
    </button>
  )
}

export default KeyPicker
