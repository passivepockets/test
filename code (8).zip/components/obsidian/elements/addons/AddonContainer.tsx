"use client"

import type { FC, ReactNode } from "react"
import { cn } from "@/lib/utils"

interface AddonContainerProps {
  children: ReactNode
  className?: string
}

const AddonContainer: FC<AddonContainerProps> = ({ children, className }) => {
  return <div className={cn("flex items-center gap-2", className)}>{children}</div>
}

export default AddonContainer
