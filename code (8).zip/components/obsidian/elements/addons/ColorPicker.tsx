"use client"

import type { FC } from "react"
import { useUIValue } from "../../UIStateProvider"
import { cn } from "@/lib/utils"

interface ColorPickerProps {
  title?: string
  defaultValue?: string
  className?: string
  stateKey: string
}

const ColorPicker: FC<ColorPickerProps> = ({ title = "Color", defaultValue = "#ffffff", className, stateKey }) => {
  const [value, setValue] = useUIValue(stateKey, defaultValue)

  return (
    <div className={cn("flex items-center gap-2", className)}>
      <span className="text-xs text-white/70">{title}</span>
      <input
        type="color"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        className="h-6 w-12 cursor-pointer rounded border border-white/20 bg-transparent"
      />
    </div>
  )
}

export default ColorPicker
