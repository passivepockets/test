export default function Divider() {
  return <hr className="w-full h-[4px] border-[rgb(40,40,40)] border mt-0 mb-0" />
}
