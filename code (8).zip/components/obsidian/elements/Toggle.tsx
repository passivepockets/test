"use client"

import type { FC } from "react"
import { useUIValue } from "../UIStateProvider"
import { cn } from "@/lib/utils"

interface ToggleProps {
  text: string
  risky?: boolean
  checked: boolean
  stateKey: string
}

const Toggle: FC<ToggleProps> = ({ text, risky, checked: defaultChecked, stateKey }) => {
  const [checked, setChecked] = useUIValue(stateKey, defaultChecked)

  return (
    <div className="flex items-center justify-between gap-2 py-1.5">
      <span className={cn("text-sm text-white/90", risky && "text-red-400")}>{text}</span>
      <button
        onClick={() => setChecked(!checked)}
        className={cn("relative h-5 w-9 rounded-full transition-colors", checked ? "bg-blue-500" : "bg-white/20")}
      >
        <span
          className={cn(
            "absolute top-0.5 h-4 w-4 rounded-full bg-white transition-transform",
            checked ? "left-[18px]" : "left-0.5",
          )}
        />
      </button>
    </div>
  )
}

export default Toggle
