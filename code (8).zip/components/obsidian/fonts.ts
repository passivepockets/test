import { IBM_Plex_Mono } from "next/font/google"
export const IBMMono = IBM_Plex_Mono({
  weight: ["400"],
  subsets: ["latin"],
  variable: "--font",
})
