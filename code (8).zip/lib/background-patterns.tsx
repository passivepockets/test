import type React from "react"

// Hexagon pattern
export function HexagonPattern({ opacity = 0.03, color = "218, 165, 32" }) {
  return (
    <div
      className="absolute inset-0 opacity-[var(--pattern-opacity)]"
      style={
        {
          "--pattern-opacity": opacity,
          backgroundImage: `radial-gradient(circle at 50% 50%, rgba(${color}, 0.4) 2px, transparent 2px)`,
          backgroundSize: "30px 30px",
          backgroundPosition: "0 0, 15px 15px",
        } as React.CSSProperties
      }
    />
  )
}

// Circuit board pattern
export function CircuitPattern({ opacity = 0.02, color = "218, 165, 32" }) {
  return (
    <div
      className="absolute inset-0 opacity-[var(--pattern-opacity)]"
      style={
        {
          "--pattern-opacity": opacity,
          backgroundImage: `
            linear-gradient(90deg, rgba(${color}, 0.3) 1px, transparent 1px),
            linear-gradient(rgba(${color}, 0.3) 1px, transparent 1px),
            linear-gradient(90deg, rgba(${color}, 0.2) 1px, transparent 1px),
            linear-gradient(rgba(${color}, 0.2) 1px, transparent 1px)
          `,
          backgroundSize: "100px 100px, 100px 100px, 20px 20px, 20px 20px",
          backgroundPosition: "-2px -2px, -2px -2px, -1px -1px, -1px -1px",
        } as React.CSSProperties
      }
    />
  )
}

// Dots pattern
export function DotsPattern({ opacity = 0.15, color = "255, 255, 255" }) {
  return (
    <div
      className="absolute inset-0 opacity-[var(--pattern-opacity)]"
      style={
        {
          "--pattern-opacity": opacity,
          backgroundImage: `radial-gradient(circle, rgba(${color}, 1) 1px, transparent 1px)`,
          backgroundSize: "24px 24px",
        } as React.CSSProperties
      }
    />
  )
}

// Diagonal stripes pattern
export function DiagonalStripesPattern({ opacity = 0.02, color = "218, 165, 32" }) {
  return (
    <div
      className="absolute inset-0 opacity-[var(--pattern-opacity)]"
      style={
        {
          "--pattern-opacity": opacity,
          backgroundImage: `repeating-linear-gradient(
            45deg,
            transparent,
            transparent 35px,
            rgba(${color}, 0.4) 35px,
            rgba(${color}, 0.4) 36px
          )`,
        } as React.CSSProperties
      }
    />
  )
}

// Cross hatch pattern
export function CrossHatchPattern({ opacity = 0.02, color = "218, 165, 32" }) {
  return (
    <div
      className="absolute inset-0 opacity-[var(--pattern-opacity)]"
      style={
        {
          "--pattern-opacity": opacity,
          backgroundImage: `
            repeating-linear-gradient(45deg, transparent, transparent 20px, rgba(${color}, 0.3) 20px, rgba(${color}, 0.3) 21px),
            repeating-linear-gradient(-45deg, transparent, transparent 20px, rgba(${color}, 0.3) 20px, rgba(${color}, 0.3) 21px)
          `,
        } as React.CSSProperties
      }
    />
  )
}

// Zigzag pattern
export function ZigzagPattern({ opacity = 0.02, color = "218, 165, 32" }) {
  return (
    <div
      className="absolute inset-0 opacity-[var(--pattern-opacity)]"
      style={
        {
          "--pattern-opacity": opacity,
          backgroundImage: `
            linear-gradient(135deg, rgba(${color}, 0.3) 25%, transparent 25%),
            linear-gradient(225deg, rgba(${color}, 0.3) 25%, transparent 25%),
            linear-gradient(45deg, rgba(${color}, 0.3) 25%, transparent 25%),
            linear-gradient(315deg, rgba(${color}, 0.3) 25%, transparent 25%)
          `,
          backgroundSize: "40px 40px",
          backgroundPosition: "0 0, 20px 0, 20px -20px, 0px 20px",
        } as React.CSSProperties
      }
    />
  )
}

// Triangles pattern
export function TrianglesPattern({ opacity = 0.02, color = "218, 165, 32" }) {
  return (
    <div
      className="absolute inset-0 opacity-[var(--pattern-opacity)]"
      style={
        {
          "--pattern-opacity": opacity,
          backgroundImage: `
            linear-gradient(45deg, transparent 50%, rgba(${color}, 0.3) 50%),
            linear-gradient(-45deg, transparent 50%, rgba(${color}, 0.3) 50%)
          `,
          backgroundSize: "30px 30px",
          backgroundPosition: "0 0, 15px 15px",
        } as React.CSSProperties
      }
    />
  )
}

// Waves pattern
export function WavesPattern({ opacity = 0.02, color = "218, 165, 32" }) {
  return (
    <div
      className="absolute inset-0 opacity-[var(--pattern-opacity)]"
      style={
        {
          "--pattern-opacity": opacity,
          backgroundImage: `repeating-radial-gradient(circle at 0 0, transparent 0, rgba(${color}, 0.2) 10px, transparent 20px)`,
        } as React.CSSProperties
      }
    />
  )
}

// Plus signs pattern
export function PlusPattern({ opacity = 0.02, color = "218, 165, 32" }) {
  return (
    <div
      className="absolute inset-0 opacity-[var(--pattern-opacity)]"
      style={
        {
          "--pattern-opacity": opacity,
          backgroundImage: `
            linear-gradient(90deg, rgba(${color}, 0.3) 1px, transparent 1px),
            linear-gradient(rgba(${color}, 0.3) 1px, transparent 1px)
          `,
          backgroundSize: "20px 20px",
          backgroundPosition: "center center",
        } as React.CSSProperties
      }
    />
  )
}

// Scattered dots pattern
export function ScatteredDotsPattern({ opacity = 0.03, color = "218, 165, 32" }) {
  return (
    <div
      className="absolute inset-0 opacity-[var(--pattern-opacity)]"
      style={
        {
          "--pattern-opacity": opacity,
          backgroundImage: `
            radial-gradient(circle, rgba(${color}, 0.4) 1px, transparent 1px),
            radial-gradient(circle, rgba(${color}, 0.3) 1px, transparent 1px)
          `,
          backgroundSize: "50px 50px, 80px 80px",
          backgroundPosition: "0 0, 40px 60px",
        } as React.CSSProperties
      }
    />
  )
}
