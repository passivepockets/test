import type React from "react"
import {
  HexagonPattern,
  CircuitPattern,
  DotsPattern,
  DiagonalStripesPattern,
  CrossHatchPattern,
  ZigzagPattern,
  TrianglesPattern,
  WavesPattern,
  PlusPattern,
  ScatteredDotsPattern,
} from "./background-patterns"

interface PatternBackgroundProps {
  children: React.ReactNode
  pattern?:
    | "hexagon"
    | "circuit"
    | "dots"
    | "diagonal"
    | "crosshatch"
    | "zigzag"
    | "triangles"
    | "waves"
    | "plus"
    | "scattered"
  glowPosition?: "top-left" | "top-right" | "bottom-left" | "bottom-right" | "center" | "top-center" | "bottom-center"
  glowColor?: "yellow" | "amber" | "gold"
  className?: string
}

export function PatternBackground({
  children,
  pattern = "dots",
  glowPosition = "center",
  glowColor = "yellow",
  className = "",
}: PatternBackgroundProps) {
  const glowPositions = {
    "top-left": "top-1/4 left-1/4",
    "top-right": "top-1/4 right-1/4",
    "bottom-left": "bottom-1/4 left-1/4",
    "bottom-right": "bottom-1/4 right-1/4",
    center: "top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2",
    "top-center": "top-1/4 left-1/2 -translate-x-1/2",
    "bottom-center": "bottom-1/4 left-1/2 -translate-x-1/2",
  }

  const glowColors = {
    yellow: "bg-[#FFB800]/8",
    amber: "bg-[#FFA500]/8",
    gold: "bg-[#FFBF00]/8",
  }

  const patterns = {
    hexagon: <HexagonPattern />,
    circuit: <CircuitPattern />,
    dots: <DotsPattern />,
    diagonal: <DiagonalStripesPattern />,
    crosshatch: <CrossHatchPattern />,
    zigzag: <ZigzagPattern />,
    triangles: <TrianglesPattern />,
    waves: <WavesPattern />,
    plus: <PlusPattern />,
    scattered: <ScatteredDotsPattern />,
  }

  return (
    <div className={`relative ${className}`}>
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div
          className={`absolute ${glowPositions[glowPosition]} w-96 h-96 ${glowColors[glowColor]} rounded-full blur-3xl`}
        />
        {patterns[pattern]}
      </div>
      {children}
    </div>
  )
}
